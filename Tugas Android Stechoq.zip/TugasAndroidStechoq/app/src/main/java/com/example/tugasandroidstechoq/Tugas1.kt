package com.example.tugasandroidstechoq

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Tugas1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tugas1)
    }
}